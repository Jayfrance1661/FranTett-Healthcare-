﻿<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>FranTett Healthcare - Staff Dashboard</title>

    <style>
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        :root {
            --primary: #0b6b5c;
            --primary-dark: #095448;
            --primary-light: #e8f5f2;

            --danger: #c0392b;
            --danger-dark: #a93226;

            --warning: #f39c12;
            --info: #2980b9;
            --success: #27ae60;

            --text: #222;
            --muted: #666;
            --light: #f4f7f9;
            --white: #ffffff;
            --border: #e5e7eb;

            --shadow: 0 2px 10px rgba(0, 0, 0, 0.07);
            --shadow-hover: 0 6px 18px rgba(0, 0, 0, 0.12);
        }

        body {
            font-family: Arial, Helvetica, sans-serif;
            background: var(--light);
            color: var(--text);
            line-height: 1.6;
            min-height: 100vh;
        }

        /* =========================================
           HEADER
        ========================================= */

        header {
            background: var(--primary);
            color: white;
            padding: 16px 40px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 20px;
            position: sticky;
            top: 0;
            z-index: 1000;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.12);
        }

        .logo {
            font-size: 24px;
            font-weight: bold;
            white-space: nowrap;
        }

        .nav-toggle {
            display: none;
            border: none;
            background: transparent;
            color: white;
            font-size: 27px;
            cursor: pointer;
            padding: 5px 8px;
        }

        nav {
            display: flex;
            align-items: center;
            gap: 8px;
            flex-wrap: wrap;
        }

        nav a {
            color: white;
            text-decoration: none;
            font-size: 14px;
            padding: 8px 11px;
            border-radius: 6px;
            transition: background 0.2s;
        }

        nav a:hover,
        nav a.active {
            background: rgba(255, 255, 255, 0.15);
        }

        .logout-btn {
            background: var(--danger);
            color: white;
            border: none;
            padding: 9px 15px;
            border-radius: 6px;
            cursor: pointer;
            font-size: 14px;
            font-weight: bold;
            transition: background 0.2s, transform 0.2s;
        }

        .logout-btn:hover {
            background: var(--danger-dark);
            transform: translateY(-1px);
        }

        /* =========================================
           MAIN
        ========================================= */

        .container {
            width: 92%;
            max-width: 1400px;
            margin: 35px auto;
        }

        .page-header {
            margin-bottom: 25px;
        }

        .page-header-top {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            gap: 20px;
        }

        .page-header h1 {
            color: var(--primary);
            margin-bottom: 6px;
            font-size: 32px;
        }

        .page-header p {
            color: var(--muted);
        }

        .header-actions {
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
        }

        /* =========================================
           BUTTONS
        ========================================= */

        .btn {
            border: none;
            border-radius: 6px;
            padding: 10px 15px;
            font-size: 14px;
            font-weight: bold;
            cursor: pointer;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 7px;
            transition: 0.2s;
        }

        .btn-primary {
            background: var(--primary);
            color: white;
        }

        .btn-primary:hover {
            background: var(--primary-dark);
            transform: translateY(-1px);
        }

        .btn-secondary {
            background: #eef2f3;
            color: #333;
        }

        .btn-secondary:hover {
            background: #dfe5e7;
        }

        .btn-danger {
            background: var(--danger);
            color: white;
        }

        .btn-danger:hover {
            background: var(--danger-dark);
        }

        .btn-info {
            background: var(--info);
            color: white;
        }

        .btn-success {
            background: var(--success);
            color: white;
        }

        .btn-warning {
            background: var(--warning);
            color: white;
        }

        .btn:disabled {
            opacity: 0.6;
            cursor: not-allowed;
            transform: none;
        }

        /* =========================================
           MAIN STATISTICS
        ========================================= */

        .stats-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 20px;
            margin-bottom: 25px;
        }

        .stat-card {
            background: var(--white);
            border-radius: 10px;
            padding: 24px;
            box-shadow: var(--shadow);
            border-left: 5px solid var(--primary);
            transition: transform 0.2s, box-shadow 0.2s;
        }

        .stat-card:hover {
            transform: translateY(-2px);
            box-shadow: var(--shadow-hover);
        }

        .stat-card h3 {
            color: #555;
            font-size: 15px;
            margin-bottom: 10px;
        }

        .stat-card .number {
            font-size: 34px;
            font-weight: bold;
            color: var(--primary);
            word-break: break-word;
        }

        .stat-card p {
            color: #888;
            font-size: 13px;
            margin-top: 4px;
        }

        .stat-icon {
            font-size: 25px;
            float: right;
        }

        .message-stat {
            border-left-color: var(--warning);
        }

        .message-stat .number {
            color: var(--warning);
        }

        /* =========================================
           STATUS
        ========================================= */

        .status-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 20px;
            margin-bottom: 30px;
        }

        .status-card {
            background: var(--white);
            border-radius: 10px;
            padding: 20px;
            text-align: center;
            box-shadow: var(--shadow);
            transition: transform 0.2s;
        }

        .status-card:hover {
            transform: translateY(-2px);
        }

        .status-card h3 {
            font-size: 16px;
            margin-bottom: 8px;
        }

        .status-number {
            font-size: 30px;
            font-weight: bold;
        }

        .pending {
            border-top: 4px solid var(--warning);
        }

        .pending .status-number {
            color: var(--warning);
        }

        .confirmed {
            border-top: 4px solid var(--info);
        }

        .confirmed .status-number {
            color: var(--info);
        }

        .completed {
            border-top: 4px solid var(--success);
        }

        .completed .status-number {
            color: var(--success);
        }

        .cancelled {
            border-top: 4px solid var(--danger);
        }

        .cancelled .status-number {
            color: var(--danger);
        }

        /* =========================================
           SECTION TITLES
        ========================================= */

        .section-title {
            color: var(--primary);
            margin-bottom: 18px;
            font-size: 24px;
        }

        /* =========================================
           QUICK ACTIONS
        ========================================= */

        .quick-actions {
            display: grid;
            grid-template-columns: repeat(5, 1fr);
            gap: 20px;
            margin-bottom: 35px;
        }

        .action-card {
            background: var(--white);
            padding: 25px;
            border-radius: 10px;
            text-decoration: none;
            color: var(--text);
            box-shadow: var(--shadow);
            transition: transform 0.2s, box-shadow 0.2s;
            text-align: center;
            border: 1px solid transparent;
        }

        .action-card:hover {
            transform: translateY(-3px);
            box-shadow: var(--shadow-hover);
            border-color: #d9ece8;
        }

        .action-icon {
            font-size: 40px;
            margin-bottom: 10px;
        }

        .action-card h3 {
            color: var(--primary);
            margin-bottom: 8px;
        }

        .action-card p {
            color: #777;
            font-size: 14px;
        }

        /* =========================================
           SECTIONS
        ========================================= */

        .appointments-section,
        .messages-section {
            background: var(--white);
            border-radius: 10px;
            padding: 25px;
            box-shadow: var(--shadow);
            margin-bottom: 30px;
        }

        .section-heading {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
            gap: 15px;
            flex-wrap: wrap;
        }

        .section-heading h2 {
            color: var(--primary);
            font-size: 23px;
        }

        .appointment-actions,
        .message-actions {
            display: flex;
            gap: 8px;
            flex-wrap: wrap;
        }

        /* =========================================
           TABLE
        ========================================= */

        .table-wrapper {
            overflow-x: auto;
            border: 1px solid var(--border);
            border-radius: 7px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            min-width: 850px;
        }

        th {
            background: var(--primary);
            color: white;
            padding: 12px;
            text-align: left;
            font-size: 14px;
            white-space: nowrap;
        }

        td {
            padding: 12px;
            border-bottom: 1px solid #eee;
            font-size: 14px;
            vertical-align: middle;
        }

        tbody tr:last-child td {
            border-bottom: none;
        }

        tbody tr:hover {
            background: #f8fbfa;
        }

        .message-row-new {
            background: #fffaf0;
        }

        .message-row-new:hover {
            background: #fff5df;
        }

        /* =========================================
           STATUS BADGES
        ========================================= */

        .status-badge {
            display: inline-block;
            padding: 5px 10px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: bold;
            white-space: nowrap;
        }

        .status-pending,
        .status-new {
            background: #fff3cd;
            color: #856404;
        }

        .status-confirmed {
            background: #dbeafe;
            color: #1d4ed8;
        }

        .status-completed,
        .status-replied {
            background: #d1fae5;
            color: #065f46;
        }

        .status-cancelled {
            background: #fee2e2;
            color: #991b1b;
        }

        .status-read {
            background: #e5e7eb;
            color: #374151;
        }

        /* =========================================
           TABLE ACTIONS
        ========================================= */

        .table-actions {
            display: flex;
            gap: 6px;
            flex-wrap: wrap;
        }

        .small-btn {
            border: none;
            border-radius: 5px;
            padding: 6px 9px;
            cursor: pointer;
            font-size: 12px;
            font-weight: bold;
        }

        .small-btn.view {
            background: #e8f5f2;
            color: var(--primary);
        }

        .small-btn.read {
            background: #e5e7eb;
            color: #374151;
        }

        .small-btn.replied {
            background: #d1fae5;
            color: #065f46;
        }

        .small-btn.delete {
            background: #fee2e2;
            color: #991b1b;
        }

        .small-btn:hover {
            opacity: 0.8;
        }

        /* =========================================
           MESSAGES / STATES
        ========================================= */

        .loading,
        .empty-state,
        .error-message,
        .login-message {
            text-align: center;
            padding: 30px 20px;
            border-radius: 7px;
        }

        .loading {
            color: #777;
        }

        .empty-state {
            color: #666;
            background: #f8fafb;
            border: 1px dashed #d7dfe2;
        }

        .empty-state .empty-icon {
            font-size: 38px;
            margin-bottom: 8px;
        }

        .empty-state h3 {
            margin-bottom: 5px;
            color: #444;
        }

        .error-message {
            color: var(--danger);
            background: #fff5f5;
            border: 1px solid #f3cccc;
        }

        .login-message {
            color: #856404;
            background: #fff8e1;
            border: 1px solid #f1df9d;
        }

        .message-action {
            margin-top: 15px;
        }

        /* =========================================
           MODAL
        ========================================= */

        .modal {
            position: fixed;
            inset: 0;
            background: rgba(0, 0, 0, 0.55);
            display: none;
            align-items: center;
            justify-content: center;
            padding: 20px;
            z-index: 5000;
        }

        .modal.show {
            display: flex;
        }

        .modal-content {
            width: 100%;
            max-width: 700px;
            max-height: 90vh;
            overflow-y: auto;
            background: white;
            border-radius: 12px;
            box-shadow: 0 15px 50px rgba(0, 0, 0, 0.25);
        }

        .modal-header {
            background: var(--primary);
            color: white;
            padding: 18px 22px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 15px;
        }

        .modal-header h2 {
            font-size: 21px;
        }

        .modal-close {
            border: none;
            background: transparent;
            color: white;
            font-size: 27px;
            cursor: pointer;
        }

        .modal-body {
            padding: 24px;
        }

        .message-detail {
            margin-bottom: 18px;
        }

        .message-detail-label {
            font-size: 12px;
            font-weight: bold;
            color: #777;
            text-transform: uppercase;
            margin-bottom: 4px;
        }

        .message-detail-value {
            font-size: 15px;
            color: #222;
            word-break: break-word;
        }

        .message-content {
            background: #f8fafb;
            border: 1px solid var(--border);
            border-radius: 8px;
            padding: 16px;
            white-space: pre-wrap;
            min-height: 120px;
        }

        .modal-footer {
            padding: 16px 24px;
            border-top: 1px solid var(--border);
            display: flex;
            justify-content: flex-end;
            gap: 8px;
            flex-wrap: wrap;
        }

        /* =========================================
           TOAST
        ========================================= */

        .toast {
            position: fixed;
            right: 20px;
            bottom: 20px;
            max-width: 360px;
            background: #222;
            color: white;
            padding: 13px 17px;
            border-radius: 7px;
            box-shadow: 0 5px 20px rgba(0, 0, 0, 0.2);
            opacity: 0;
            visibility: hidden;
            transform: translateY(15px);
            transition: 0.25s;
            z-index: 6000;
            font-size: 14px;
        }

        .toast.show {
            opacity: 1;
            visibility: visible;
            transform: translateY(0);
        }

        .toast.success {
            background: #176b43;
        }

        .toast.error {
            background: var(--danger);
        }

        /* =========================================
           FOOTER
        ========================================= */

        footer {
            background: var(--primary);
            color: white;
            text-align: center;
            padding: 20px;
            margin-top: 40px;
        }

        /* =========================================
           MOBILE
        ========================================= */

        @media (max-width: 1200px) {
            .quick-actions {
                grid-template-columns: repeat(3, 1fr);
            }
        }

        @media (max-width: 1100px) {
            .stats-grid,
            .status-grid {
                grid-template-columns: repeat(2, 1fr);
            }
        }

        @media (max-width: 800px) {

            header {
                padding: 15px 20px;
                flex-wrap: wrap;
            }

            .nav-toggle {
                display: block;
            }

            nav {
                display: none;
                width: 100%;
                flex-direction: column;
                align-items: stretch;
                gap: 4px;
            }

            nav.open {
                display: flex;
            }

            nav a {
                display: block;
                text-align: center;
                padding: 10px;
            }

            .logout-btn {
                width: 100%;
            }

            .page-header-top {
                flex-direction: column;
            }

            .header-actions {
                width: 100%;
            }

            .header-actions .btn {
                flex: 1;
            }

            .quick-actions {
                grid-template-columns: repeat(2, 1fr);
            }
        }

        @media (max-width: 700px) {

            .container {
                width: 94%;
                margin: 25px auto;
            }

            .stats-grid,
            .status-grid,
            .quick-actions {
                grid-template-columns: 1fr;
            }

            .page-header h1 {
                font-size: 27px;
            }

            .section-heading {
                align-items: flex-start;
            }

            .appointment-actions,
            .message-actions {
                width: 100%;
            }

            .appointment-actions .btn,
            .message-actions .btn {
                flex: 1;
            }

            .stat-card {
                padding: 20px;
            }

            .appointments-section,
            .messages-section {
                padding: 18px;
            }

            .toast {
                left: 15px;
                right: 15px;
                bottom: 15px;
                max-width: none;
            }

            .modal {
                padding: 10px;
            }

            .modal-body {
                padding: 18px;
            }
        }

        /* =========================================
           PRINT
        ========================================= */

        @media print {

            body {
                background: white;
            }

            header,
            .header-actions,
            .quick-actions,
            .section-title,
            .appointment-actions,
            .message-actions,
            footer,
            .table-actions,
            .modal {
                display: none !important;
            }

            .container {
                width: 100%;
                max-width: none;
                margin: 0;
            }

            .appointments-section,
            .messages-section,
            .stat-card,
            .status-card {
                box-shadow: none;
                border: 1px solid #ddd;
            }

            .appointments-section,
            .messages-section {
                margin-top: 20px;
            }

            table {
                min-width: 0;
            }

            th {
                background: #eee !important;
                color: #000 !important;
            }

            .status-badge {
                border: 1px solid #aaa;
                background: white !important;
                color: #000 !important;
            }
        }
    </style>
</head>

<body>

    <!-- =========================================
         HEADER
    ========================================== -->

    <header>

        <div class="logo">
            FranTett Healthcare
        </div>

        <button
            class="nav-toggle"
            id="navToggle"
            type="button"
            aria-label="Open navigation"
            aria-expanded="false">
            â˜°
        </button>

        <nav id="mainNav">

            <a href="../index.html">
                Home
            </a>

            <a href="./doctors.html?staff=true">
                Doctors
            </a>

            <a href="./services.html">
                Services
            </a>

            <a href="./appointments.html">
                Book Appointment
            </a>

            <a
                href="./dashboard.html"
                class="active">
                Staff Dashboard
            </a>

            <a href="./contact.html">
                Contact
            </a>

            <button
                class="logout-btn"
                type="button"
                onclick="logout()">
                Logout
            </button>

        </nav>

    </header>


    <!-- =========================================
         MAIN
    ========================================== -->

    <main class="container">

        <div class="page-header">

            <div class="page-header-top">

                <div>

                    <h1>
                        Staff Dashboard
                    </h1>

                    <p>
                        Manage FranTett Healthcare appointments,
                        patients, contact messages, and healthcare information.
                    </p>

                </div>

                <div class="header-actions">

                    <button
                        class="btn btn-secondary"
                        type="button"
                        onclick="refreshDashboard()">
                        ðŸ”„ Refresh
                    </button>

                    <button
                        class="btn btn-primary"
                        type="button"
                        onclick="printDashboard()">
                        ðŸ–¨ï¸ Print
                    </button>

                </div>

            </div>

        </div>


        <!-- =========================================
             MAIN STATISTICS
        ========================================== -->

        <div class="stats-grid">

            <div class="stat-card">

                <span class="stat-icon">
                    ðŸ‘¥
                </span>

                <h3>
                    Total Patients
                </h3>

                <div
                    class="number"
                    id="totalPatients">
                    0
                </div>

                <p>
                    Registered patients
                </p>

            </div>


            <div class="stat-card">

                <span class="stat-icon">
                    ðŸ‘¨â€âš•ï¸
                </span>

                <h3>
                    Total Doctors
                </h3>

                <div
                    class="number"
                    id="totalDoctors">
                    0
                </div>

                <p>
                    Healthcare providers
                </p>

            </div>


            <div class="stat-card">

                <span class="stat-icon">
                    ðŸ“…
                </span>

                <h3>
                    Total Appointments
                </h3>

                <div
                    class="number"
                    id="totalAppointments">
                    0
                </div>

                <p>
                    All appointments
                </p>

            </div>


            <div class="stat-card message-stat">

                <span class="stat-icon">
                    âœ‰ï¸
                </span>

                <h3>
                    New Messages
                </h3>

                <div
                    class="number"
                    id="newMessagesCount">
                    0
                </div>

                <p>
                    Unread contact messages
                </p>

            </div>

        </div>


        <!-- =========================================
             TODAY
        ========================================== -->

        <div
            style="
                background:#ffffff;
                border-radius:10px;
                padding:18px 22px;
                box-shadow:var(--shadow);
                margin-bottom:25px;
                display:flex;
                justify-content:space-between;
                align-items:center;
                gap:15px;
                flex-wrap:wrap;
            ">

            <div>

                <strong style="color:var(--primary);">
                    Today's Date
                </strong>

            </div>

            <div
                id="todayDate"
                style="
                    font-weight:bold;
                    color:#555;
                ">
                Loading...
            </div>

        </div>


        <!-- =========================================
             APPOINTMENT STATUS
        ========================================== -->

        <div class="status-grid">

            <div class="status-card pending">

                <h3>
                    Pending
                </h3>

                <div
                    class="status-number"
                    id="pendingCount">
                    0
                </div>

            </div>


            <div class="status-card confirmed">

                <h3>
                    Confirmed
                </h3>

                <div
                    class="status-number"
                    id="confirmedCount">
                    0
                </div>

            </div>


            <div class="status-card completed">

                <h3>
                    Completed
                </h3>

                <div
                    class="status-number"
                    id="completedCount">
                    0
                </div>

            </div>


            <div class="status-card cancelled">

                <h3>
                    Cancelled
                </h3>

                <div
                    class="status-number"
                    id="cancelledCount">
                    0
                </div>

            </div>

        </div>


        <!-- =========================================
             QUICK ACTIONS
        ========================================== -->

        <h2 class="section-title">
            Quick Actions
        </h2>

        <div class="quick-actions">

            <a
                href="./appointments.html"
                class="action-card">

                <div class="action-icon">
                    ðŸ“…
                </div>

                <h3>
                    Appointments
                </h3>

                <p>
                    View, create, edit and manage
                    patient appointments.
                </p>

            </a>


            <a
                href="./patients.html"
                class="action-card">

                <div class="action-icon">
                    ðŸ‘¥
                </div>

                <h3>
                    Patients
                </h3>

                <p>
                    View patient profiles,
                    consultations and prescriptions.
                </p>

            </a>


            <a
                href="./doctors.html?staff=true"
                class="action-card">

                <div class="action-icon">
                    ðŸ‘¨â€âš•ï¸
                </div>

                <h3>
                    Doctors
                </h3>

                <p>
                    View the doctors registered
                    with FranTett Healthcare.
                </p>

            </a>


            <a
                href="./appointments.html"
                class="action-card">

                <div class="action-icon">
                    âž•
                </div>

                <h3>
                    Add Appointment
                </h3>

                <p>
                    Create a new appointment
                    for a patient.
                </p>

            </a>


            <a
                href="#contactMessages"
                class="action-card"
                onclick="scrollToMessages(event)">

                <div class="action-icon">
                    âœ‰ï¸
                </div>

                <h3>
                    Contact Messages
                </h3>

                <p>
                    View and manage messages
                    sent through the contact form.
                </p>

            </a>

        </div>


        <!-- =========================================
             RECENT APPOINTMENTS
        ========================================== -->

        
        <!-- =========================================
             STAFF REGISTRATION REQUESTS
             ADMIN ONLY
        ========================================== -->

        <section
            id="staffApprovalSection"
            style="
                display:none;
                background:#ffffff;
                border-radius:10px;
                padding:22px;
                box-shadow:var(--shadow);
                margin-bottom:25px;
                border-left:4px solid var(--primary);
            ">

            <div
                style="
                    display:flex;
                    justify-content:space-between;
                    align-items:center;
                    gap:15px;
                    flex-wrap:wrap;
                    margin-bottom:18px;
                ">

                <div>

                    <h2 style="color:var(--primary);">
                        Staff Registration Requests
                    </h2>

                    <p style="color:var(--muted); margin-top:4px;">
                        Review and approve staff accounts before they can log in.
                    </p>

                </div>

                <span
                    id="staffPendingBadge"
                    style="
                        background:var(--warning);
                        color:white;
                        border-radius:20px;
                        padding:5px 12px;
                        font-size:13px;
                        font-weight:bold;
                    ">
                    0 Pending
                </span>

            </div>


            <div
                id="staffApprovalMessage"
                style="
                    padding:18px;
                    text-align:center;
                    color:var(--muted);
                ">
                Loading staff registration requests...
            </div>


            <div
                id="staffRequestsTableWrapper"
                style="
                    display:none;
                    overflow-x:auto;
                ">

                <table
                    style="
                        width:100%;
                        border-collapse:collapse;
                    ">

                    <thead>

                        <tr>

                            <th style="padding:12px;text-align:left;">
                                Name
                            </th>

                            <th style="padding:12px;text-align:left;">
                                Email
                            </th>

                            <th style="padding:12px;text-align:left;">
                                Phone
                            </th>

                            <th style="padding:12px;text-align:left;">
                                Role
                            </th>

                            <th style="padding:12px;text-align:left;">
                                Submitted
                            </th>

                            <th style="padding:12px;text-align:left;">
                                Action
                            </th>

                        </tr>

                    </thead>

                    <tbody id="staffRequestsBody">
                    </tbody>

                </table>

            </div>

        </section>

<div class="appointments-section">

            <div class="section-heading">

                <h2>
                    Recent Appointments
                </h2>

                <div class="appointment-actions">

                    <button
                        class="btn btn-secondary"
                        type="button"
                        onclick="exportAppointments()">
                        ðŸ“¥ Export
                    </button>

                    <button
                        class="btn btn-primary"
                        type="button"
                        onclick="printAppointments()">
                        ðŸ–¨ï¸ Print
                    </button>

                    <a
                        href="./appointments.html"
                        class="btn btn-secondary">
                        View All â†’
                    </a>

                </div>

            </div>


            <div
                id="appointmentsMessage"
                class="loading">
                Loading appointments...
            </div>


            <div
                id="appointmentsTableContainer"
                class="table-wrapper"
                style="display:none;">

                <table>

                    <thead>

                        <tr>

                            <th>
                                ID
                            </th>

                            <th>
                                Patient
                            </th>

                            <th>
                                Doctor
                            </th>

                            <th>
                                Date
                            </th>

                            <th>
                                Time
                            </th>

                            <th>
                                Reason
                            </th>

                            <th>
                                Status
                            </th>

                        </tr>

                    </thead>

                    <tbody id="recentAppointmentsBody">
                    </tbody>

                </table>

            </div>

        </div>


        <!-- =========================================
             CONTACT MESSAGES
        ========================================== -->

        <div
            class="messages-section"
            id="contactMessages">

            <div class="section-heading">

                <h2>
                    Contact Messages
                </h2>

                <div class="message-actions">

                    <button
                        class="btn btn-secondary"
                        type="button"
                        onclick="loadContactMessages()">
                        ðŸ”„ Refresh
                    </button>

                    <button
                        class="btn btn-primary"
                        type="button"
                        onclick="printContactMessages()">
                        ðŸ–¨ï¸ Print
                    </button>

                </div>

            </div>


            <div
                id="contactMessagesMessage"
                class="loading">
                Loading contact messages...
            </div>


            <div
                id="contactMessagesTableContainer"
                class="table-wrapper"
                style="display:none;">

                <table>

                    <thead>

                        <tr>

                            <th>
                                ID
                            </th>

                            <th>
                                Name
                            </th>

                            <th>
                                Email
                            </th>

                            <th>
                                Subject
                            </th>

                            <th>
                                Status
                            </th>

                            <th>
                                Date
                            </th>

                            <th>
                                Actions
                            </th>

                        </tr>

                    </thead>

                    <tbody id="contactMessagesBody">
                    </tbody>

                </table>

            </div>

        </div>

    </main>


    <!-- =========================================
         FOOTER
    ========================================== -->

    <footer>

        Â© 2026 FranTett Healthcare.
        All rights reserved.

    </footer>


    <!-- =========================================
         MESSAGE VIEW MODAL
    ========================================== -->

    <div
        class="modal"
        id="messageModal"
        role="dialog"
        aria-modal="true"
        aria-labelledby="messageModalTitle">

        <div class="modal-content">

            <div class="modal-header">

                <h2 id="messageModalTitle">
                    Contact Message
                </h2>

                <button
                    class="modal-close"
                    type="button"
                    onclick="closeMessageModal()"
                    aria-label="Close">
                    Ã—
                </button>

            </div>


            <div class="modal-body">

                <div class="message-detail">

                    <div class="message-detail-label">
                        Name
                    </div>

                    <div
                        class="message-detail-value"
                        id="modalMessageName">
                        -
                    </div>

                </div>


                <div class="message-detail">

                    <div class="message-detail-label">
                        Email
                    </div>

                    <div
                        class="message-detail-value"
                        id="modalMessageEmail">
                        -
                    </div>

                </div>


                <div class="message-detail">

                    <div class="message-detail-label">
                        Subject
                    </div>

                    <div
                        class="message-detail-value"
                        id="modalMessageSubject">
                        -
                    </div>

                </div>


                <div class="message-detail">

                    <div class="message-detail-label">
                        Date
                    </div>

                    <div
                        class="message-detail-value"
                        id="modalMessageDate">
                        -
                    </div>

                </div>


                <div class="message-detail">

                    <div class="message-detail-label">
                        Status
                    </div>

                    <div
                        class="message-detail-value"
                        id="modalMessageStatus">
                        -
                    </div>

                </div>


                <div class="message-detail">

                    <div class="message-detail-label">
                        Message
                    </div>

                    <div
                        class="message-content"
                        id="modalMessageContent">
                        -
                    </div>

                </div>

            </div>


            <div class="modal-footer">

                <button
                    class="btn btn-secondary"
                    type="button"
                    onclick="closeMessageModal()">
                    Close
                </button>

                <button
                    class="btn btn-info"
                    type="button"
                    id="modalReadButton">
                    Mark Read
                </button>

                <button
                    class="btn btn-success"
                    type="button"
                    id="modalRepliedButton">
                    Mark Replied
                </button>

                <button
                    class="btn btn-danger"
                    type="button"
                    id="modalDeleteButton">
                    Delete
                </button>

            </div>

        </div>

    </div>


    <!-- =========================================
         TOAST
    ========================================== -->

    <div
        id="toast"
        class="toast"
        role="alert">
    </div>


    <script>

        const API_BASE_URL = "http://localhost:3000";

        let dashboardAppointments = [];

        let contactMessages = [];

        let currentMessageId = null;


        /* =========================================
           AUTHENTICATION
        ========================================= */

        function getToken() {

            return localStorage.getItem(
                "frantett_token"
            );

        }

        function getUserRole() {

            const token = getToken();

            if (!token) {
                return null;
            }

            try {

                const payload = JSON.parse(
                    atob(token.split('.')[1])
                );

                return payload.role || null;

            } catch (error) {

                console.error(
                    'Unable to read user role:',
                    error
                );

                return null;
            }

        }



        async function apiFetch(
            url,
            options = {}
        ) {

            const token = getToken();

            const headers = {
                ...(options.headers || {})
            };

            if (token) {

                headers["Authorization"] =
                    "Bearer " + token;

            }

            if (
                options.body &&
                !headers["Content-Type"]
            ) {

                headers["Content-Type"] =
                    "application/json";

            }

            const response =
                await fetch(
                    API_BASE_URL + url,
                    {
                        ...options,
                        headers
                    }
                );

            if (
                response.status === 401 ||
                response.status === 403
            ) {

                handleSessionExpired();

            }

            return response;

        }


        /* =========================================
           SESSION EXPIRATION
        ========================================= */

        function handleSessionExpired() {

            if (
                document.body.dataset.sessionExpired === "true"
            ) {

                return;

            }

            document.body.dataset.sessionExpired = "true";

            showToast(
                "Your staff session has expired. Please log in again.",
                "error"
            );

        }


        /* =========================================
           LOGOUT
        ========================================= */

        function logout() {

            const confirmed =
                window.confirm(
                    "Are you sure you want to log out?"
                );

            if (!confirmed) {
                return;
            }

            localStorage.removeItem(
                "frantett_token"
            );

            window.location.href =
                "../index.html";

        }


        /* =========================================
           MOBILE NAVIGATION
        ========================================= */

        function setupNavigation() {

            const toggle =
                document.getElementById(
                    "navToggle"
                );

            const nav =
                document.getElementById(
                    "mainNav"
                );

            if (!toggle || !nav) {
                return;
            }

            toggle.addEventListener(
                "click",
                function () {

                    const isOpen =
                        nav.classList.toggle(
                            "open"
                        );

                    toggle.setAttribute(
                        "aria-expanded",
                        String(isOpen)
                    );

                }
            );

            nav.querySelectorAll("a")
                .forEach(link => {

                    link.addEventListener(
                        "click",
                        function () {

                            nav.classList.remove(
                                "open"
                            );

                            toggle.setAttribute(
                                "aria-expanded",
                                "false"
                            );

                        }
                    );

                });

        }


        /* =========================================
           TOAST
        ========================================= */

        let toastTimer;

        function showToast(
            message,
            type = ""
        ) {

            const toast =
                document.getElementById(
                    "toast"
                );

            toast.textContent = message;

            toast.className =
                "toast show " + type;

            clearTimeout(toastTimer);

            toastTimer =
                setTimeout(
                    function () {

                        toast.className =
                            "toast";

                    },
                    3500
                );

        }


        /* =========================================
           PRINT
        ========================================= */

        function printDashboard() {

            window.print();

        }


        function printAppointments() {

            window.print();

        }


        function printContactMessages() {

            window.print();

        }


        /* =========================================
           ESCAPE HTML
        ========================================= */

        function escapeHtml(value) {

            if (
                value === null ||
                value === undefined
            ) {

                return "";

            }

            return String(value)
                .replace(/&/g, "&amp;")
                .replace(/</g, "&lt;")
                .replace(/>/g, "&gt;")
                .replace(/"/g, "&quot;")
                .replace(/'/g, "&#039;");

        }


        /* =========================================
           PATIENT NAME
        ========================================= */

        function getPatientName(appointment) {

            if (
                appointment.patient_name &&
                typeof appointment.patient_name === "string"
            ) {

                return appointment.patient_name;

            }

            if (
                appointment.patientName &&
                typeof appointment.patientName === "string"
            ) {

                return appointment.patientName;

            }

            const patient =
                appointment.patient;

            if (
                patient &&
                typeof patient === "object"
            ) {

                if (patient.patient_name) {
                    return patient.patient_name;
                }

                if (patient.patientName) {
                    return patient.patientName;
                }

                if (patient.name) {
                    return patient.name;
                }

                if (patient.full_name) {
                    return patient.full_name;
                }

                if (patient.fullName) {
                    return patient.fullName;
                }

                if (
                    patient.first_name ||
                    patient.last_name
                ) {

                    return [
                        patient.first_name || "",
                        patient.last_name || ""
                    ]
                        .join(" ")
                        .trim();

                }

                if (
                    patient.firstName ||
                    patient.lastName
                ) {

                    return [
                        patient.firstName || "",
                        patient.lastName || ""
                    ]
                        .join(" ")
                        .trim();

                }

            }

            if (
                typeof patient === "string"
            ) {

                return patient;

            }

            if (appointment.full_name) {
                return appointment.full_name;
            }

            if (appointment.fullName) {
                return appointment.fullName;
            }

            if (appointment.name) {
                return appointment.name;
            }

            if (
                appointment.first_name ||
                appointment.last_name
            ) {

                return [
                    appointment.first_name || "",
                    appointment.last_name || ""
                ]
                    .join(" ")
                    .trim();

            }

            if (
                appointment.firstName ||
                appointment.lastName
            ) {

                return [
                    appointment.firstName || "",
                    appointment.lastName || ""
                ]
                    .join(" ")
                    .trim();

            }

            return "-";

        }


        /* =========================================
           DOCTOR NAME
        ========================================= */

        function getDoctorName(appointment) {

            if (appointment.doctor_name) {
                return appointment.doctor_name;
            }

            if (appointment.doctorName) {
                return appointment.doctorName;
            }

            if (
                typeof appointment.doctor === "string"
            ) {

                return appointment.doctor;

            }

            if (
                appointment.doctor &&
                typeof appointment.doctor === "object"
            ) {

                if (appointment.doctor.name) {
                    return appointment.doctor.name;
                }

                if (appointment.doctor.doctor_name) {
                    return appointment.doctor.doctor_name;
                }

                if (appointment.doctor.full_name) {
                    return appointment.doctor.full_name;
                }

            }

            return "-";

        }


        /* =========================================
           DATE
        ========================================= */

        function formatAppointmentDate(value) {

            if (!value) {
                return "-";
            }

            const valueString =
                String(value).trim();

            const match =
                valueString.match(
                    /^(\d{4})-(\d{2})-(\d{2})/
                );

            if (match) {

                const year =
                    Number(match[1]);

                const month =
                    Number(match[2]);

                const day =
                    Number(match[3]);

                const date =
                    new Date(
                        year,
                        month - 1,
                        day
                    );

                if (
                    !isNaN(date.getTime())
                ) {

                    return date.toLocaleDateString(
                        "en-US",
                        {
                            month: "short",
                            day: "numeric",
                            year: "numeric"
                        }
                    );

                }

            }

            const date =
                new Date(value);

            if (
                isNaN(date.getTime())
            ) {

                return valueString;

            }

            return date.toLocaleDateString(
                "en-US",
                {
                    month: "short",
                    day: "numeric",
                    year: "numeric"
                }
            );

        }


        /* =========================================
           MESSAGE DATE
        ========================================= */

        function formatMessageDate(value) {

            if (!value) {
                return "-";
            }

            const date =
                new Date(value);

            if (
                isNaN(date.getTime())
            ) {

                return String(value);

            }

            return date.toLocaleString(
                "en-US",
                {
                    month: "short",
                    day: "numeric",
                    year: "numeric",
                    hour: "numeric",
                    minute: "2-digit"
                }
            );

        }


        /* =========================================
           APPOINTMENT STATUS
        ========================================= */

        function formatStatus(status) {

            if (!status) {
                return "Pending";
            }

            const value =
                String(status);

            return (
                value.charAt(0).toUpperCase() +
                value.slice(1).toLowerCase()
            );

        }


        function getStatusClass(status) {

            const value =
                String(
                    status || "pending"
                ).toLowerCase();

            if (value === "confirmed") {
                return "status-confirmed";
            }

            if (value === "completed") {
                return "status-completed";
            }

            if (value === "cancelled") {
                return "status-cancelled";
            }

            return "status-pending";

        }


        /* =========================================
           CONTACT MESSAGE STATUS
        ========================================= */

        function formatMessageStatus(status) {

            if (!status) {
                return "New";
            }

            const value =
                String(status)
                    .trim()
                    .toLowerCase();

            if (value === "new") {
                return "New";
            }

            if (value === "read") {
                return "Read";
            }

            if (value === "replied") {
                return "Replied";
            }

            return value.charAt(0).toUpperCase() +
                value.slice(1);

        }


        function getMessageStatusClass(status) {

            const value =
                String(
                    status || "new"
                )
                    .trim()
                    .toLowerCase();

            if (value === "read") {
                return "status-read";
            }

            if (value === "replied") {
                return "status-replied";
            }

            return "status-new";

        }


        /* =========================================
           TODAY'S DATE
        ========================================= */

        function loadTodayDate() {

            const today =
                new Date();

            document.getElementById(
                "todayDate"
            ).textContent =
                today.toLocaleDateString(
                    "en-US",
                    {
                        month: "short",
                        day: "numeric",
                        year: "numeric"
                    }
                );

        }


        /* =========================================
           LOAD DOCTORS
        ========================================= */

        async function loadDoctors() {

            try {

                const response =
                    await apiFetch(
                        "/api/doctors"
                    );

                if (!response.ok) {

                    throw new Error(
                        `HTTP ${response.status}`
                    );

                }

                const data =
                    await response.json();

                let doctors = data;

                if (
                    data &&
                    Array.isArray(data.doctors)
                ) {

                    doctors =
                        data.doctors;

                }

                document.getElementById(
                    "totalDoctors"
                ).textContent =
                    Array.isArray(doctors)
                        ? doctors.length
                        : 0;

            }
            catch (error) {

                console.error(
                    "Unable to load doctors:",
                    error
                );

                document.getElementById(
                    "totalDoctors"
                ).textContent = "â€”";

            }

        }


        /* =========================================
           LOAD PATIENTS
        ========================================= */

        async function loadPatients() {

            try {

                const response =
                    await apiFetch(
                        "/api/patients"
                    );

                if (!response.ok) {

                    throw new Error(
                        `HTTP ${response.status}`
                    );

                }

                const data =
                    await response.json();

                let patients = data;

                if (
                    data &&
                    Array.isArray(data.patients)
                ) {

                    patients =
                        data.patients;

                }

                document.getElementById(
                    "totalPatients"
                ).textContent =
                    Array.isArray(patients)
                        ? patients.length
                        : 0;

            }
            catch (error) {

                console.error(
                    "Unable to load patients:",
                    error
                );

                document.getElementById(
                    "totalPatients"
                ).textContent = "â€”";

            }

        }


        /* =========================================
           LOAD APPOINTMENTS
        ========================================= */

        async function loadAppointments() {

            const message =
                document.getElementById(
                    "appointmentsMessage"
                );

            const tableContainer =
                document.getElementById(
                    "appointmentsTableContainer"
                );

            const tbody =
                document.getElementById(
                    "recentAppointmentsBody"
                );

            const token =
                getToken();

            if (!token) {

                message.className =
                    "login-message";

                message.innerHTML = `
                    <strong>Staff session required.</strong>
                    <br>
                    Please log in again to access the dashboard.

                    <div class="message-action">

                        <button
                            class="btn btn-primary"
                            type="button"
                            onclick="window.location.href='../index.html'">
                            Go to Login
                        </button>

                    </div>
                `;

                tableContainer.style.display =
                    "none";

                return;

            }

            try {

                message.className =
                    "loading";

                message.textContent =
                    "Loading appointments...";

                message.style.display =
                    "block";

                tableContainer.style.display =
                    "none";

                const response =
                    await apiFetch(
                        "/api/appointments"
                    );

                if (
                    response.status === 401 ||
                    response.status === 403
                ) {

                    message.className =
                        "login-message";

                    message.innerHTML = `
                        <strong>Your staff session has expired.</strong>
                        <br>
                        Please log in again.

                        <div class="message-action">

                            <button
                                class="btn btn-primary"
                                type="button"
                                onclick="window.location.href='../index.html'">
                                Go to Login
                            </button>

                        </div>
                    `;

                    return;

                }

                if (!response.ok) {

                    throw new Error(
                        `HTTP ${response.status}`
                    );

                }

                const data =
                    await response.json();

                let appointments = data;

                if (
                    data &&
                    Array.isArray(data.appointments)
                ) {

                    appointments =
                        data.appointments;

                }

                if (
                    !Array.isArray(appointments)
                ) {

                    appointments = [];

                }

                dashboardAppointments =
                    [...appointments];

                document.getElementById(
                    "totalAppointments"
                ).textContent =
                    appointments.length;


                let pending = 0;
                let confirmed = 0;
                let completed = 0;
                let cancelled = 0;


                appointments.forEach(
                    appointment => {

                        const status =
                            String(
                                appointment.status ||
                                "Pending"
                            )
                                .toLowerCase()
                                .trim();

                        if (status === "pending") {
                            pending++;
                        }
                        else if (status === "confirmed") {
                            confirmed++;
                        }
                        else if (status === "completed") {
                            completed++;
                        }
                        else if (status === "cancelled") {
                            cancelled++;
                        }

                    }
                );


                document.getElementById(
                    "pendingCount"
                ).textContent =
                    pending;

                document.getElementById(
                    "confirmedCount"
                ).textContent =
                    confirmed;

                document.getElementById(
                    "completedCount"
                ).textContent =
                    completed;

                document.getElementById(
                    "cancelledCount"
                ).textContent =
                    cancelled;


                appointments.sort(
                    (a, b) => {

                        const dateA =
                            new Date(
                                `${a.appointment_date || ""}T${a.appointment_time || "00:00"}`
                            );

                        const dateB =
                            new Date(
                                `${b.appointment_date || ""}T${b.appointment_time || "00:00"}`
                            );

                        return dateB - dateA;

                    }
                );


                const recent =
                    appointments.slice(0, 5);

                tbody.innerHTML = "";


                if (recent.length === 0) {

                    message.className =
                        "empty-state";

                    message.innerHTML = `
                        <div class="empty-icon">
                            ðŸ“…
                        </div>

                        <h3>
                            No appointments yet
                        </h3>

                        <p>
                            There are currently no appointments
                            in the system.
                        </p>

                        <div class="message-action">

                            <a
                                href="./appointments.html"
                                class="btn btn-primary">
                                Add Appointment
                            </a>

                        </div>
                    `;

                    tableContainer.style.display =
                        "none";

                    return;

                }


                recent.forEach(
                    appointment => {

                        const row =
                            document.createElement(
                                "tr"
                            );

                        const patientName =
                            getPatientName(
                                appointment
                            );

                        const doctorName =
                            getDoctorName(
                                appointment
                            );

                        const date =
                            formatAppointmentDate(
                                appointment.appointment_date
                            );

                        const time =
                            appointment.appointment_time ||
                            "-";

                        const reason =
                            appointment.reason ||
                            "-";

                        const status =
                            formatStatus(
                                appointment.status
                            );

                        const statusClass =
                            getStatusClass(
                                appointment.status
                            );


                        row.innerHTML = `

                            <td>
                                ${escapeHtml(
                                    appointment.id ?? "-"
                                )}
                            </td>

                            <td>
                                ${escapeHtml(
                                    patientName
                                )}
                            </td>

                            <td>
                                ${escapeHtml(
                                    doctorName
                                )}
                            </td>

                            <td>
                                ${escapeHtml(
                                    date
                                )}
                            </td>

                            <td>
                                ${escapeHtml(
                                    time
                                )}
                            </td>

                            <td>
                                ${escapeHtml(
                                    reason
                                )}
                            </td>

                            <td>

                                <span
                                    class="status-badge ${statusClass}">
                                    ${escapeHtml(
                                        status
                                    )}
                                </span>

                            </td>

                        `;

                        tbody.appendChild(row);

                    }
                );


                message.style.display =
                    "none";

                tableContainer.style.display =
                    "block";

            }
            catch (error) {

                console.error(
                    "Unable to load appointments:",
                    error
                );

                message.className =
                    "error-message";

                message.innerHTML = `

                    <strong>
                        Unable to load appointments.
                    </strong>

                    <br>

                    There was a problem communicating
                    with the server.

                    <div class="message-action">

                        <button
                            class="btn btn-primary"
                            type="button"
                            onclick="loadAppointments()">
                            ðŸ”„ Try Again
                        </button>

                    </div>

                `;

                tableContainer.style.display =
                    "none";

            }

        }


        /* =========================================
           LOAD CONTACT MESSAGES
        ========================================= */

        async function loadContactMessages() {

            const message =
                document.getElementById(
                    "contactMessagesMessage"
                );

            const tableContainer =
                document.getElementById(
                    "contactMessagesTableContainer"
                );

            const tbody =
                document.getElementById(
                    "contactMessagesBody"
                );


            const token =
                getToken();


            if (!token) {

                message.className =
                    "login-message";

                message.innerHTML = `

                    <strong>
                        Staff session required.
                    </strong>

                    <br>

                    Please log in again to access
                    contact messages.

                    <div class="message-action">

                        <button
                            class="btn btn-primary"
                            type="button"
                            onclick="window.location.href='../index.html'">
                            Go to Login
                        </button>

                    </div>

                `;

                tableContainer.style.display =
                    "none";

                return;

            }


            try {

                message.className =
                    "loading";

                message.textContent =
                    "Loading contact messages...";

                message.style.display =
                    "block";

                tableContainer.style.display =
                    "none";


                const response =
                    await apiFetch(
                        "/api/contact"
                    );


                if (
                    response.status === 401 ||
                    response.status === 403
                ) {

                    message.className =
                        "login-message";

                    message.innerHTML = `

                        <strong>
                            Your staff session has expired.
                        </strong>

                        <br>

                        Please log in again.

                        <div class="message-action">

                            <button
                                class="btn btn-primary"
                                type="button"
                                onclick="window.location.href='../index.html'">
                                Go to Login
                            </button>

                        </div>

                    `;

                    return;

                }


                if (!response.ok) {

                    throw new Error(
                        `HTTP ${response.status}`
                    );

                }


                const data =
                    await response.json();


                let messages =
                    data;


                if (
                    data &&
                    Array.isArray(data.messages)
                ) {

                    messages =
                        data.messages;

                }


                if (
                    data &&
                    Array.isArray(data.contactMessages)
                ) {

                    messages =
                        data.contactMessages;

                }


                if (!Array.isArray(messages)) {

                    messages = [];

                }


                contactMessages =
                    [...messages];


                /* NEW MESSAGE COUNT */

                const newCount =
                    contactMessages.filter(
                        message => {

                            return String(
                                message.status || "New"
                            )
                                .toLowerCase()
                                .trim() === "new";

                        }
                    ).length;


                document.getElementById(
                    "newMessagesCount"
                ).textContent =
                    newCount;


                /* SORT NEWEST FIRST */

                contactMessages.sort(
                    (a, b) => {

                        const dateA =
                            new Date(
                                a.created_at ||
                                a.createdAt ||
                                0
                            );

                        const dateB =
                            new Date(
                                b.created_at ||
                                b.createdAt ||
                                0
                            );

                        return dateB - dateA;

                    }
                );


                /* SHOW ONLY FIVE */

                const recentMessages =
                    contactMessages.slice(0, 5);


                tbody.innerHTML = "";


                if (
                    recentMessages.length === 0
                ) {

                    message.className =
                        "empty-state";

                    message.innerHTML = `

                        <div class="empty-icon">
                            âœ‰ï¸
                        </div>

                        <h3>
                            No contact messages
                        </h3>

                        <p>
                            There are currently no messages
                            submitted through the contact form.
                        </p>

                    `;

                    tableContainer.style.display =
                        "none";

                    return;

                }


                recentMessages.forEach(
                    contactMessage => {

                        const row =
                            document.createElement(
                                "tr"
                            );


                        const status =
                            formatMessageStatus(
                                contactMessage.status
                            );


                        const statusClass =
                            getMessageStatusClass(
                                contactMessage.status
                            );


                        const createdAt =
                            contactMessage.created_at ||
                            contactMessage.createdAt;


                        const isNew =
                            String(
                                contactMessage.status ||
                                "New"
                            )
                                .toLowerCase()
                                .trim() === "new";


                        if (isNew) {

                            row.classList.add(
                                "message-row-new"
                            );

                        }


                        row.innerHTML = `

                            <td>
                                ${escapeHtml(
                                    contactMessage.id ?? "-"
                                )}
                            </td>

                            <td>
                                <strong>
                                    ${escapeHtml(
                                        contactMessage.name || "-"
                                    )}
                                </strong>
                            </td>

                            <td>
                                ${escapeHtml(
                                    contactMessage.email || "-"
                                )}
                            </td>

                            <td>
                                ${escapeHtml(
                                    contactMessage.subject || "-"
                                )}
                            </td>

                            <td>

                                <span
                                    class="status-badge ${statusClass}">
                                    ${escapeHtml(
                                        status
                                    )}
                                </span>

                            </td>

                            <td>
                                ${escapeHtml(
                                    formatMessageDate(
                                        createdAt
                                    )
                                )}
                            </td>

                            <td>

                                <div class="table-actions">

                                    <button
                                        class="small-btn view"
                                        type="button"
                                        onclick="viewContactMessage(${Number(
                                            contactMessage.id
                                        )})">
                                        View
                                    </button>

                                    ${
                                        isNew
                                        ? `
                                            <button
                                                class="small-btn read"
                                                type="button"
                                                onclick="updateMessageStatus(${Number(
                                                    contactMessage.id
                                                )}, 'Read')">
                                                Read
                                            </button>
                                        `
                                        : ""
                                    }

                                    ${
                                        String(
                                            contactMessage.status || ""
                                        ).toLowerCase() !== "replied"
                                        ? `
                                            <button
                                                class="small-btn replied"
                                                type="button"
                                                onclick="updateMessageStatus(${Number(
                                                    contactMessage.id
                                                )}, 'Replied')">
                                                Replied
                                            </button>
                                        `
                                        : ""
                                    }

                                    <button
                                        class="small-btn delete"
                                        type="button"
                                        onclick="deleteContactMessage(${Number(
                                            contactMessage.id
                                        )})">
                                        Delete
                                    </button>

                                </div>

                            </td>

                        `;


                        tbody.appendChild(row);

                    }
                );


                message.style.display =
                    "none";

                tableContainer.style.display =
                    "block";

            }
            catch (error) {

                console.error(
                    "Unable to load contact messages:",
                    error
                );


                message.className =
                    "error-message";


                message.innerHTML = `

                    <strong>
                        Unable to load contact messages.
                    </strong>

                    <br>

                    There was a problem communicating
                    with the server.

                    <div class="message-action">

                        <button
                            class="btn btn-primary"
                            type="button"
                            onclick="loadContactMessages()">
                            ðŸ”„ Try Again
                        </button>

                    </div>

                `;


                tableContainer.style.display =
                    "none";


                document.getElementById(
                    "newMessagesCount"
                ).textContent =
                    "â€”";

            }

        }


        /* =========================================
           VIEW CONTACT MESSAGE
        ========================================= */

        async function viewContactMessage(id) {

            currentMessageId = id;


            try {

                const response =
                    await apiFetch(
                        `/api/contact/${encodeURIComponent(id)}`
                    );


                if (
                    response.status === 401 ||
                    response.status === 403
                ) {

                    return;

                }


                if (!response.ok) {

                    throw new Error(
                        `HTTP ${response.status}`
                    );

                }


                const data =
                    await response.json();


              let message = data;


// Backend returns the single contact message as "contact"
if (
    data &&
    data.contact &&
    typeof data.contact === "object"
) {

    message = data.contact;

}


// Support alternative response formats as well
else if (
    data &&
    data.message &&
    typeof data.message === "object"
) {

    message = data.message;

}


else if (
    data &&
    data.contactMessage &&
    typeof data.contactMessage === "object"
) {

    message = data.contactMessage;

}


                if (
                    !message ||
                    typeof message !== "object"
                ) {

                    throw new Error(
                        "Invalid message data"
                    );

                }


                document.getElementById(
                    "modalMessageName"
                ).textContent =
                    message.name || "-";


                document.getElementById(
                    "modalMessageEmail"
                ).textContent =
                    message.email || "-";


                document.getElementById(
                    "modalMessageSubject"
                ).textContent =
                    message.subject || "-";


                document.getElementById(
                    "modalMessageDate"
                ).textContent =
                    formatMessageDate(
                        message.created_at ||
                        message.createdAt
                    );


                document.getElementById(
                    "modalMessageStatus"
                ).innerHTML = `

                    <span
                        class="status-badge ${getMessageStatusClass(
                            message.status
                        )}">

                        ${escapeHtml(
                            formatMessageStatus(
                                message.status
                            )
                        )}

                    </span>

                `;


                document.getElementById(
                    "modalMessageContent"
                ).textContent =
                    message.message ||
                    message.content ||
                    message.body ||
                    "-";


                const readButton =
                    document.getElementById(
                        "modalReadButton"
                    );


                const repliedButton =
                    document.getElementById(
                        "modalRepliedButton"
                    );


                const deleteButton =
                    document.getElementById(
                        "modalDeleteButton"
                    );


                readButton.onclick =
                    function () {

                        updateMessageStatus(
                            id,
                            "Read"
                        );

                    };


                repliedButton.onclick =
                    function () {

                        updateMessageStatus(
                            id,
                            "Replied"
                        );

                    };


                deleteButton.onclick =
                    function () {

                        deleteContactMessage(
                            id
                        );

                    };


                document.getElementById(
                    "messageModal"
                ).classList.add(
                    "show"
                );


            }
            catch (error) {

                console.error(
                    "Unable to view contact message:",
                    error
                );


                showToast(
                    "Unable to load the contact message.",
                    "error"
                );

            }

        }


        /* =========================================
           CLOSE MESSAGE MODAL
        ========================================= */

        function closeMessageModal() {

            document.getElementById(
                "messageModal"
            ).classList.remove(
                "show"
            );

            currentMessageId =
                null;

        }


        /* =========================================
           UPDATE MESSAGE STATUS
        ========================================= */

        async function updateMessageStatus(
            id,
            status
        ) {

            try {

                const response =
                    await apiFetch(
                        `/api/contact/${encodeURIComponent(id)}/status`,
                        {
                            method: "PATCH",
                            body: JSON.stringify({
                                status: status
                            })
                        }
                    );


                if (
                    response.status === 401 ||
                    response.status === 403
                ) {

                    return;

                }


                if (!response.ok) {

                    let errorText =
                        "";

                    try {

                        errorText =
                            await response.text();

                    }
                    catch (_) {}

                    throw new Error(
                        errorText ||
                        `HTTP ${response.status}`
                    );

                }


                showToast(
                    `Message marked as ${status}.`,
                    "success"
                );


                closeMessageModal();


                await loadContactMessages();

            }
            catch (error) {

                console.error(
                    "Unable to update message status:",
                    error
                );


                showToast(
                    "Unable to update the message status.",
                    "error"
                );

            }

        }


        /* =========================================
           DELETE CONTACT MESSAGE
        ========================================= */

        async function deleteContactMessage(id) {

            const confirmed =
                window.confirm(
                    "Are you sure you want to delete this contact message? This action cannot be undone."
                );


            if (!confirmed) {

                return;

            }


            try {

                const response =
                    await apiFetch(
                        `/api/contact/${encodeURIComponent(id)}`,
                        {
                            method: "DELETE"
                        }
                    );


                if (
                    response.status === 401 ||
                    response.status === 403
                ) {

                    return;

                }


                if (!response.ok) {

                    let errorText =
                        "";

                    try {

                        errorText =
                            await response.text();

                    }
                    catch (_) {}

                    throw new Error(
                        errorText ||
                        `HTTP ${response.status}`
                    );

                }


                showToast(
                    "Contact message deleted successfully.",
                    "success"
                );


                closeMessageModal();


                await loadContactMessages();

            }
            catch (error) {

                console.error(
                    "Unable to delete contact message:",
                    error
                );


                showToast(
                    "Unable to delete the contact message.",
                    "error"
                );

            }

        }


        /* =========================================
           SCROLL TO CONTACT MESSAGES
        ========================================= */

        function scrollToMessages(event) {

            event.preventDefault();

            const section =
                document.getElementById(
                    "contactMessages"
                );

            if (section) {

                section.scrollIntoView({
                    behavior: "smooth",
                    block: "start"
                });

            }

        }


        /* =========================================
           EXPORT APPOINTMENTS
        ========================================= */

        function exportAppointments() {

            if (
                dashboardAppointments.length === 0
            ) {

                showToast(
                    "There are no appointments to export.",
                    "error"
                );

                return;

            }


            const headers = [
                "ID",
                "Patient",
                "Doctor",
                "Date",
                "Time",
                "Reason",
                "Status"
            ];


            const rows =
                dashboardAppointments.map(
                    appointment => [

                        appointment.id ?? "",

                        getPatientName(
                            appointment
                        ),

                        getDoctorName(
                            appointment
                        ),

                        formatAppointmentDate(
                            appointment.appointment_date
                        ),

                        appointment.appointment_time ||
                            "",

                        appointment.reason ||
                            "",

                        formatStatus(
                            appointment.status
                        )

                    ]
                );


            const csvRows = [
                headers,
                ...rows
            ];


            const csv =
                csvRows
                    .map(
                        row =>
                            row
                                .map(
                                    value =>
                                        `"${String(
                                            value ?? ""
                                        ).replace(
                                            /"/g,
                                            '""'
                                        )}"`
                                )
                                .join(",")
                    )
                    .join("\n");


            const blob =
                new Blob(
                    [csv],
                    {
                        type:
                            "text/csv;charset=utf-8;"
                    }
                );


            const url =
                URL.createObjectURL(
                    blob
                );


            const link =
                document.createElement(
                    "a"
                );


            link.href =
                url;


            const date =
                new Date()
                    .toISOString()
                    .slice(
                        0,
                        10
                    );


            link.download =
                `frantett-appointments-${date}.csv`;


            document.body.appendChild(
                link
            );


            link.click();


            document.body.removeChild(
                link
            );


            URL.revokeObjectURL(
                url
            );


            showToast(
                "Appointments exported successfully.",
                "success"
            );

        }


        /* =========================================
           REFRESH DASHBOARD
        ========================================= */

        async function refreshDashboard() {

            showToast(
                "Refreshing dashboard..."
            );


            loadTodayDate();


            await Promise.all([
                loadDoctors(),
                loadPatients(),
                loadAppointments(),
                loadContactMessages()
            ]);


            showToast(
                "Dashboard refreshed.",
                "success"
            );

        }



        /* =========================================
           STAFF REGISTRATION APPROVAL
           ADMIN ONLY
        ========================================= */

        async function loadStaffRegistrationRequests() {

            const section =
                document.getElementById(
                    "staffApprovalSection"
                );

            if (!section) {
                return;
            }

            try {

                const response =
                    await apiFetch(
                        "/api/staff/registration-requests"
                    );

                if (response.status === 403) {

                    section.style.display = "none";

                    return;

                }

                if (!response.ok) {

                    throw new Error(
                        "Failed to load staff registration requests."
                    );

                }

                const requests =
                    await response.json();

                section.style.display = "block";

                const badge =
                    document.getElementById(
                        "staffPendingBadge"
                    );

                const message =
                    document.getElementById(
                        "staffApprovalMessage"
                    );

                const tableWrapper =
                    document.getElementById(
                        "staffRequestsTableWrapper"
                    );

                const tbody =
                    document.getElementById(
                        "staffRequestsBody"
                    );

                const pendingRequests =
                    requests.filter(
                        request =>
                            request.status === "Pending"
                    );

                badge.textContent =
                    `${pendingRequests.length} Pending`;

                tbody.innerHTML = "";

                if (pendingRequests.length === 0) {

                    message.style.display = "block";

                    message.textContent =
                        "There are no pending staff registration requests.";

                    tableWrapper.style.display = "none";

                    return;

                }

                message.style.display = "none";

                tableWrapper.style.display = "block";

                pendingRequests.forEach(
                    request => {

                        const row =
                            document.createElement("tr");

                        row.innerHTML = `

                            <td style="padding:12px;">
                                ${escapeHtml(
                                    request.full_name || ""
                                )}
                            </td>

                            <td style="padding:12px;">
                                ${escapeHtml(
                                    request.email || ""
                                )}
                            </td>

                            <td style="padding:12px;">
                                ${escapeHtml(
                                    request.phone || "â€”"
                                )}
                            </td>

                            <td style="padding:12px;">
                                ${escapeHtml(
                                    request.role || "Staff"
                                )}
                            </td>

                            <td style="padding:12px;">
                                ${formatStaffDate(
                                    request.created_at
                                )}
                            </td>

                            <td style="padding:12px;">

                                <div
                                    style="
                                        display:flex;
                                        gap:8px;
                                        flex-wrap:wrap;
                                    ">

                                    <button
                                        type="button"
                                        class="btn btn-primary"
                                        onclick="approveStaffRegistration(${request.id})">
                                        Approve
                                    </button>

                                    <button
                                        type="button"
                                        class="btn"
                                        style="
                                            background:var(--danger);
                                            color:white;
                                        "
                                        onclick="rejectStaffRegistration(${request.id})">
                                        Reject
                                    </button>

                                </div>

                            </td>

                        `;

                        tbody.appendChild(row);

                    }
                );

            } catch (error) {

                console.error(
                    "Load staff registration requests error:",
                    error
                );

                section.style.display = "block";

                const message =
                    document.getElementById(
                        "staffApprovalMessage"
                    );

                if (message) {

                    message.style.display = "block";

                    message.textContent =
                        "Unable to load staff registration requests.";

                }

            }

        }


        /* =========================================
           APPROVE STAFF REGISTRATION
        ========================================= */

        async function approveStaffRegistration(id) {

            const confirmed =
                window.confirm(
                    "Approve this staff registration request?"
                );

            if (!confirmed) {
                return;
            }

            try {

                const response =
                    await apiFetch(
                        `/api/staff/registration-requests/${encodeURIComponent(id)}/approve`,
                        {
                            method: "PUT"
                        }
                    );

                const data =
                    await response.json();

                if (!response.ok) {

                    throw new Error(
                        data.message ||
                        "Failed to approve staff registration."
                    );

                }

                showToast(
                    "Staff registration approved successfully.",
                    "success"
                );

                await loadStaffRegistrationRequests();

            } catch (error) {

                console.error(
                    "Approve staff registration error:",
                    error
                );

                showToast(
                    error.message ||
                    "Unable to approve staff registration.",
                    "error"
                );

            }

        }


        /* =========================================
           REJECT STAFF REGISTRATION
        ========================================= */

        async function rejectStaffRegistration(id) {

            const confirmed =
                window.confirm(
                    "Reject this staff registration request?"
                );

            if (!confirmed) {
                return;
            }

            try {

                const response =
                    await apiFetch(
                        `/api/staff/registration-requests/${encodeURIComponent(id)}/reject`,
                        {
                            method: "PUT"
                        }
                    );

                const data =
                    await response.json();

                if (!response.ok) {

                    throw new Error(
                        data.message ||
                        "Failed to reject staff registration."
                    );

                }

                showToast(
                    "Staff registration rejected successfully.",
                    "success"
                );

                await loadStaffRegistrationRequests();

            } catch (error) {

                console.error(
                    "Reject staff registration error:",
                    error
                );

                showToast(
                    error.message ||
                    "Unable to reject staff registration.",
                    "error"
                );

            }

        }


        /* =========================================
           STAFF DATE FORMAT
        ========================================= */

        function formatStaffDate(value) {

            if (!value) {
                return "â€”";
            }

            const date =
                new Date(value);

            if (isNaN(date.getTime())) {
                return "â€”";
            }

            return date.toLocaleString(
                undefined,
                {
                    year: "numeric",
                    month: "short",
                    day: "numeric",
                    hour: "2-digit",
                    minute: "2-digit"
                }
            );

        }


        /* =========================================
           HTML ESCAPE
        ========================================= */

        function escapeHtml(value) {

            return String(value)
                .replace(/&/g, "&amp;")
                .replace(/</g, "&lt;")
                .replace(/>/g, "&gt;")
                .replace(/"/g, "&quot;")
                .replace(/'/g, "&#039;");

        }

        /* =========================================
           LOAD DASHBOARD
        ========================================= */

        async function loadDashboard() {

            loadTodayDate();


            await Promise.all([
                loadDoctors(),
                loadPatients(),
                loadAppointments(),
                loadContactMessages(),
                loadStaffRegistrationRequests()
            ]);

        }


        /* =========================================
           CLOSE MODAL WHEN CLICKING OUTSIDE
        ========================================= */

        document.addEventListener(
            "click",
            function(event) {

                const modal =
                    document.getElementById(
                        "messageModal"
                    );

                if (
                    event.target === modal
                ) {

                    closeMessageModal();

                }

            }
        );


        /* =========================================
           ESC KEY
        ========================================= */

        document.addEventListener(
            "keydown",
            function(event) {

                if (
                    event.key === "Escape"
                ) {

                    closeMessageModal();

                }

            }
        );


        /* =========================================
           START
        ========================================= */

        document.addEventListener(
            "DOMContentLoaded",
            function () {

                setupNavigation();

                loadDashboard();

            }
        );

    </script>

</body>
</html>
